<?php
  include "connect.php";

  $nr = $_REQUEST["nr"];

   $joiners = $pdo->prepare("SELECT id, max_joiners, joiners  FROM posted_act ORDER BY id DESC LIMIT 24");
   $joiners->execute();
   $joiners_fetched = $joiners->fetchAll();
   $actId = $joiners_fetched[$nr]["id"];
   $maxJoiners =  $joiners_fetched[$nr]["max_joiners"];
   $joined = $joiners_fetched[$nr]["joiners"];

   if ($maxJoiners > $joiners) {
     $newJoiners = $maxJoiners + 1;
     echo $newJoiners;
     // $newJoinersIn = $pdo->prepare("UPDATE posted_act SET joiners = ? WHERE id = ?");
     // $newJoinersIn->execute([$newJoiners, $actId]);
   }
   // echo "dette er max_joiners: " . $joiners_fetched[$nr]["max_joiners"] . " dette er joined ppl: " . $joiners_fetched[$nr]["joiners"];


?>
