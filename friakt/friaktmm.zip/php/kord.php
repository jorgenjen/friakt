<?php
include "connect.php";
  $z = $_REQUEST["z"];

   $lat = $pdo->prepare("SELECT lat FROM posted_act ORDER BY id DESC LIMIT 24");
   $lat->execute();

    $lat_fetched = $lat->fetchAll();

   echo $lat_fetched[$z]["lat"];


 ?>
