<?php
   $acts = $pdo->prepare("SELECT * FROM posted_act ORDER BY id DESC LIMIT 24");
   $acts->execute();
   $acts_affected = $acts->rowCount();
   $acts_fetched = $acts->fetchAll();

   #echo $acts_fetched[1]["activety"] . " dette er antall affected: " . $acts_affected;


 ?>
