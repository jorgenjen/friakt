<?php
if (isset($_COOKIE["theUnknownNinjaCookie"])) {
  if (isset($_COOKIE["sessionkjeksen"])) {

    $hashedCookie = sha1($_COOKIE["sessionkjeksen"]);

    $compliance = $pdo->prepare("SELECT id FROM kjeksentillogin WHERE kjekse = ?"); #denne er bare til for å sjekke om kjeksene samsvarer
    $compliance->execute([$hashedCookie]);
    if ($compliance->fetch()) {
      $user_id_query = $pdo->prepare("SELECT netuser_id FROM kjeksentillogin WHERE kjekse = ?");
      $user_id_query->execute([$hashedCookie]);
      $user_id = ($user_id_query->fetchAll())[0]["netuser_id"];

      $about_you = $pdo->prepare("SELECT fornavn, surname, gender FROM networksusers WHERE id = ?");
      $about_you->execute([$user_id]);
      $about_you_fetched = $about_you->fetchAll();

      $user_name = $about_you_fetched[0]["fornavn"];
      $user_lastname = $about_you_fetched[0]["surname"];
      $user_gender = $about_you_fetched[0]["gender"];
     }
    else {
      redirect('http://localhost/sm/login.php');
    }
  }
  else {
    redirect('http://localhost/sm/login.php');
  }
}
else {
  redirect('http://localhost/sm/signup.php');
}
function redirect($url){
  header('location: ' . $url);
}

 ?>
