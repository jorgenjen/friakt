<?php
include "connect.php";

if (isset($_COOKIE["sessionkjeksen"])) {
  $hashedCookie = sha1($_COOKIE["sessionkjeksen"]);

  $compliance = $pdo->prepare("DELETE FROM kjeksentillogin WHERE kjekse = ?"); #denne er bare til for å sjekke om kjeksene samsvarer
  $compliance->execute([$hashedCookie]);

  setcookie("sessionkjeksen", "logout", time() - (60*60), '/');

  header("location: http://localhost/sm/browse.php");

}


 ?>
