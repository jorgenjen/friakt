<?php
include "connect.php";
$mail = $_GET["email"];
cookie();
function cookie(){
  GLOBAL $pdo, $mail;
  $chars = array_merge(range('a','z'), range(0,9), range('A','Z'));
  $userCookie = '';
  $lengde = rand(65, 75);
  for ($i=0; $i < $lengde; $i++) {
    $randNum = rand(0, (count($chars)-1));
    $userCookie .= $chars[$randNum];

  }
  $userCookieCrypt = sha1($userCookie);
  $existence = $pdo->prepare("SELECT id FROM kjeksentillogin WHERE kjekse = ?");
  $existence->execute([$userCookieCrypt]);
  if ($existence->fetch()) {
    $userCookie = '';
    cookie();
  }
  else{

    $userIdQuery = $pdo->prepare("SELECT id FROM networksusers WHERE epost = ?");
    $userIdQuery->execute([$mail]);
    $userId = ($userIdQuery->fetchAll())[0]["id"];


    $kjeks = $pdo->prepare("INSERT INTO kjeksentillogin(kjekse, netuser_id) VALUES (?, ?)");
    $kjeks->execute([$userCookieCrypt, $userId]);
    setcookie("sessionkjeksen", $userCookie, time() + (60*60*24*60), '/');
    setcookie("theUnknownNinjaCookie", "wasd", time() + (60*60*24*40), '/');

    header("location: http://localhost/sm/browse.php");
  }
}

 ?>
